function solve() {

  //TODO...
}